﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BillingETL.DAL.Queries;

namespace BillingETL.BLL
{
    public class Processor
    {
        /// <summary>
        /// Executes the ETL process for all ActivityTypes.
        /// </summary>
        /// <returns>The number of rows affected</returns>
        public static int Execute(DateTime startDate, DateTime endDate)
        {
            int returnValue;
            //TODO: execute the ETL process here
            //This might be a good place to use LINQ to Object for transferring to Activity tables?

            GetAssignmentsCompleted query = new GetAssignmentsCompleted(startDate, endDate);
            returnValue = query.Execute().Count();

            return returnValue;
        }

        /// <summary>
        /// Executes the ETL process for a given ActivityType.
        /// </summary>
        /// <param name="activityTypeID"></param>
        /// <returns>The number of rows affected</returns>
        public static int Execute(DateTime startDate, DateTime endDate, int activityTypeID)
        {
            int returnValue = 0;
            //TODO: run the ETL process for a specific Activity Type.

            return returnValue;
        }
    }
}
