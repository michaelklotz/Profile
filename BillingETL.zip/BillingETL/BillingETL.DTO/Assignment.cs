﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BillingETL.DTO
{
    public class Assignment
    {
        //Nullable data types in case we don't get a value back
        public int? AssignmentID { get; set; }
        public int? LoadNum { get; set; }
        public string CompletedBy { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string Status { get; set; }

        #region Constructors
        public Assignment()
        {

        }

        public Assignment(int? pAssignmentID, int? pLoadNum, string pCompletedBy, DateTime? pCompletedDate, string pStatus)
        {
            this.AssignmentID = pAssignmentID;
            this.LoadNum = pLoadNum;
            this.CompletedBy = pCompletedBy;
            this.CompletedDate = pCompletedDate;
            this.Status = pStatus;
        }
        #endregion
    }
}
