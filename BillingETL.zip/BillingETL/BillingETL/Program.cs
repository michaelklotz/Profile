﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BillingETL
{
    public class Program
    {
        static void Main(string[] args)
        {
            //These are default start/end dates because the Stored Proc's don't have date parameters yet.
            //Just pass to the DAL and ignore from there.
            DateTime START_DATE = new DateTime(1990, 1, 1);
            DateTime END_DATE = new DateTime(2020, 1, 1);


            //TODO: add an input parameter for the ActivityTypeID to be run (plus include a way to run all).
            try
            {
                Console.WriteLine("Stored Proc returned this many rows: " + BillingETL.BLL.Processor.Execute(START_DATE, END_DATE).ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Thrown: " + ex.Message);
                Console.WriteLine(String.Empty);
                Console.WriteLine("Inner Exception: " + ex.InnerException.Message);
            }
            Console.WriteLine("Press Any key...");
            Console.ReadKey();
        }
    }
}
