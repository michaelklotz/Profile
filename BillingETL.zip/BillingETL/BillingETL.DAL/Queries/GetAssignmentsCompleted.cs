﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using BillingETL.DTO;

namespace BillingETL.DAL.Queries
{
    public class GetAssignmentsCompleted
    {
        private DateTime _startDate;
        private DateTime _endDate;

        public GetAssignmentsCompleted(DateTime startDate, DateTime endDate)
        {
            //For now, accepts a start and end date but does not pass parameters to the stored procedure.
            //Due to the age of the test data, the dates should be sent to the DAL but not to the SP.
            _startDate = startDate;
            _endDate = endDate;
        }

        public List<Assignment> Execute()
        {
            try
            {
                //This does an auto-mapping from the SProc output to the Assignment object.  If the output
                // differed at all, you would need to implement an IResultSetMapper.
                object[] paramArray = new object[] { };
                Database chrDB = new SqlDatabase(ConnectionStrings.CHRobinsonDB);
                var assignments = chrDB.ExecuteSprocAccessor<Assignment>("GetAssignmentsCompleted", paramArray);
                return assignments.ToList<Assignment>();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                throw new Exception("Error connecting to the database.  Be sure your App.config file is correct, the database exists, and the stored procedure exists.", ex);
            }
        }
    }
}
