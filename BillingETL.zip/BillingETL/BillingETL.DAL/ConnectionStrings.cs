﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Configuration;
using System.Reflection;

namespace BillingETL.DAL
{
    public class ConnectionStrings
    {
        public static string CHRobinsonDB
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["CHRobinsonDB"].ConnectionString;
            }

        }
    }
}
